
public enum MazeObjectType {
    WALL,
    AGENT,
    HOLE,
    GOLD;
}
