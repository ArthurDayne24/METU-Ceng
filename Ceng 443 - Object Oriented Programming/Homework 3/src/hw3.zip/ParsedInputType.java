public enum ParsedInputType {
    CREATE_MAZE,
    SELECT_MAZE,
    DELETE_MAZE,
    CREATE_OBJECT,
    DELETE_OBJECT,
    LIST_AGENTS,
    MOVE_AGENT,
    PRINT_MAZE,
    QUIT;
}
